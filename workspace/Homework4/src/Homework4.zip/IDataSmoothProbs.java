import java.util.LinkedList;

interface IDataSmoothProbs {
  LinkedList<Double> dataSmooth(LinkedList<PHR> phrs);
}