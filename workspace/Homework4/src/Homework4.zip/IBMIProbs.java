import java.util.LinkedList;

interface IBMIProbs {
  BMISummary bmiReport(LinkedList<PHR> phrs);
}