import java.util.LinkedList;

interface IFreqWordsProbs {
  LinkedList<String> frequentWords(LinkedList<String> words);
}