class MaxHzReport {
  int day;
  double maxReading;

  MaxHzReport(int day, double maxread) {
    this.day = day;
    this.maxReading = maxread;
  }
}
