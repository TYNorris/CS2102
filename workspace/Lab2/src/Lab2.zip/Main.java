import tester.Tester;

public class Main {
  static Examples E = new Examples () ;

  public static void main(String[] args) {
    
	    Tester.run(E);
  }
}
